### Imports ###

import sys
import os
from argparse import ArgumentParser
import cv2
import numpy as np
from scipy import spatial
import time
import logging as log
from openvino.inference_engine import IENetwork, IEPlugin
import paho.mqtt.client as mqtt
import json
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

### Setup of object detection class ###

class OpenVinoObjectDetectionModel(object):

    def __init__(self, **kwargs):
        """
        Builds an OpenVINO model.

        Keyword arguments (in order):
        model_path: Path to an .xml file with a trained model.
        cpu_extension: MKLDNN (CPU)-targeted custom layers. Absolute path to a shared library with the kernels impl.
        plugin_dir: Path to a plugin folder
        device: Specify the target device to infer on; CPU, GPU, FPGA or MYRIAD is acceptable. CPU by default.
        labels_path: Labels mapping file (format .labels)
        prob_threshold: Probability threshold for detections filtering. Float between 0.0 and 1.0.
        """

        self.__dict__.update(kwargs)
        log.basicConfig(format="[ %(levelname)s ] %(message)s", level=log.INFO, stream=sys.stdout)
        self.generate(**kwargs)
        log.info("DETECT: Model initialized and loaded.")

    def generate(self, model_path, classes, cpu_extension = None, plugin_dir = None, device = "CPU",
                labels_path = None, prob_threshold = 0.5):

        self.model_xml = model_path
        self.model_bin = os.path.splitext(self.model_xml)[0] + ".bin"
        self.classes = classes

        # Plugin initialization for specified device and load extensions library if specified
        log.info("DETECT: Initializing plugin for {} device...".format(device))
        self.plugin = IEPlugin(device=device, plugin_dirs=plugin_dir)
        if cpu_extension and 'CPU' in device:
            self.plugin.add_cpu_extension(cpu_extension)

        # Read IR
        log.info("DETECT: Reading IR...")
        self.net = IENetwork.from_ir(model=self.model_xml, weights=self.model_bin)

        if "CPU" in self.plugin.device:
            supported_layers = self.plugin.get_supported_layers(self.net)
            not_supported_layers = [l for l in self.net.layers.keys() if l not in supported_layers]
            if len(not_supported_layers) != 0:
                log.error("DETECT: Following layers are not supported by the plugin for specified device {}:\n {}".
                          format(self.plugin.device, ', '.join(not_supported_layers)))
                log.error("DETECT: Please try to specify cpu extensions library path in sample's command line parameters using -l "
                          "or --cpu_extension command line argument")
                raise ValueError("DETECT: Some layers are not supported by the plugin for the specified device {}".format(device))

        assert len(self.net.inputs.keys()) == 1, "DETECT: Sample supports only single input topologies"
        assert len(self.net.outputs) == 1, "DETECT: Sample supports only single output topologies"
        self.input_blob = next(iter(self.net.inputs))
        self.out_blob = next(iter(self.net.outputs))
        log.info("DETECT: Loading IR to the plugin...")
        self.exec_net = self.plugin.load(network=self.net)

        self.n, self.c, self.h, self.w = self.net.inputs[self.input_blob].shape
        del self.net

    def detect_objects(self, image, resolution):
        """
        Runs inference on the supplied image.

        Keyword arguments:
        image: Image to be inferenced on
        resolution: Tuple of (width, height) of the image
        """

        image = cv2.resize(image, (self.w, self.h))
        image = image.transpose((2, 0, 1))  # Change data layout from HWC to CHW
        image = image.reshape((self.n, self.c, self.h, self.w))

        # Execute inference and parse results
        res = self.exec_net.infer(inputs = {self.input_blob: image})
        res = res[self.out_blob]
        bboxes = []

        for obj in res[0][0]:
            # Draw only objects when probability more than specified threshold
            confidence = obj[2]
            if confidence > self.prob_threshold:
                xmin = max(0, int(obj[3] * resolution[0]))
                ymin = max(0, int(obj[4] * resolution[1]))
                xmax = min(resolution[0], int(obj[5] * resolution[0]))
                ymax = min(resolution[1], int(obj[6] * resolution[1]))
                class_id = int(obj[1])
                bboxes.append((self.classes[class_id], confidence, xmin, ymin, xmax, ymax))

        return bboxes

### Setup of facial landmark detector
class OpenVinoFacialLandmarkModel(object):

    def __init__(self, **kwargs):
        """
        Builds an OpenVINO model.

        Keyword arguments (in order):
        model_path: Path to an .xml file with a trained model.
        cpu_extension: MKLDNN (CPU)-targeted custom layers. Absolute path to a shared library with the kernels impl.
        plugin_dir: Path to a plugin folder
        device: Specify the target device to infer on; CPU, GPU, FPGA or MYRIAD is acceptable. CPU by default.
        labels_path: Labels mapping file (format .labels)
        prob_threshold: Probability threshold for detections filtering. Float between 0.0 and 1.0.
        """

        self.__dict__.update(kwargs)
        log.basicConfig(format="[ %(levelname)s ] %(message)s", level=log.INFO, stream=sys.stdout)
        self.generate(**kwargs)
        log.info("LANDMARK: Model initialized and loaded.")

    def generate(self, model_path, cpu_extension = None, plugin_dir = None, device = "CPU",
                labels_path = None):

        self.model_xml = model_path
        self.model_bin = os.path.splitext(self.model_xml)[0] + ".bin"

        # Plugin initialization for specified device and load extensions library if specified
        log.info("LANDMARK: Initializing plugin for {} device...".format(device))
        self.plugin = IEPlugin(device=device, plugin_dirs=plugin_dir)
        if cpu_extension and 'CPU' in device:
            self.plugin.add_cpu_extension(cpu_extension)

        # Read IR
        log.info("LANDMARK: Reading IR...")
        self.net = IENetwork.from_ir(model=self.model_xml, weights=self.model_bin)

        if "CPU" in self.plugin.device:
            supported_layers = self.plugin.get_supported_layers(self.net)
            not_supported_layers = [l for l in self.net.layers.keys() if l not in supported_layers]
            if len(not_supported_layers) != 0:
                log.error("LANDMARK: Following layers are not supported by the plugin for specified device {}:\n {}".
                          format(self.plugin.device, ', '.join(not_supported_layers)))
                log.error("LANDMARK: Please try to specify cpu extensions library path in sample's command line parameters using -l "
                          "or --cpu_extension command line argument")
                raise ValueError("Some layers are not supported by the plugin for the specified device {}".format(device))

        assert len(self.net.inputs.keys()) == 1, "LANDMARK: Sample supports only single input topologies"
        assert len(self.net.outputs) == 1, "LANDMARK: Sample supports only single output topologies"
        self.input_blob = next(iter(self.net.inputs))
        self.out_blob = next(iter(self.net.outputs))
        log.info("LANDMARK: Loading IR to the plugin...")
        self.exec_net = self.plugin.load(network=self.net)

        self.n, self.c, self.h, self.w = self.net.inputs[self.input_blob].shape
        del self.net

    def detect_facial_landmarks(self, image):
        """
        Runs inference on the supplied image.

        Keyword arguments:
        image: Image to be inferenced on
        """

        image = image.copy()
        image = image[...,::-1] # Change channel order to RGB
        image = cv2.resize(image, (self.w, self.h))
        image = image.transpose((2, 0, 1))  # Change data layout from HWC to CHW
        image = image.reshape((self.n, self.c, self.h, self.w))

        # Execute inference and parse results
        res = self.exec_net.infer(inputs = {self.input_blob: image})
        res = res[self.out_blob]
        landmarks = {"eye_left": (res[0][0], res[0][1]),
                     "eye_right": (res[0][2], res[0][3]),
                     "nose": (res[0][4], res[0][5]),
                     "lip_left": (res[0][6], res[0][7]),
                     "lip_right": (res[0][8], res[0][9])}

        return landmarks

### Setup of re-identification class
class OpenVinoFaceIdentificationModel(object):

    def __init__(self, **kwargs):
        """
        Builds an OpenVINO model.

        Keyword arguments (in order):
        model_path: Path to an .xml file with a trained model.
        cpu_extension: MKLDNN (CPU)-targeted custom layers. Absolute path to a shared library with the kernels impl.
        plugin_dir: Path to a plugin folder
        device: Specify the target device to infer on; CPU, GPU, FPGA or MYRIAD is acceptable. CPU by default.
        labels_path: Labels mapping file (format .labels)
        known_persons_file: File containing vectors representing known persons
        """

        self.__dict__.update(kwargs)
        log.basicConfig(format="[ %(levelname)s ] %(message)s", level=log.INFO, stream=sys.stdout)
        self.generate(**kwargs)
        self.lib = EmbeddingLibrary(self.known_persons_file)
        log.info("Reidentification model initialized and loaded.")

    def generate(self, model_path, cpu_extension = None, plugin_dir = None, device = "CPU",
                labels_path = None, known_persons_file = None):

        self.model_xml = model_path
        self.model_bin = os.path.splitext(self.model_xml)[0] + ".bin"

        # Plugin initialization for specified device and load extensions library if specified
        log.info("REID: Initializing plugin for {} device...".format(device))
        self.plugin = IEPlugin(device=device, plugin_dirs=plugin_dir)
        if cpu_extension and 'CPU' in device:
            self.plugin.add_cpu_extension(cpu_extension)

        # Read IR
        log.info("REID: Reading IR...")
        self.net = IENetwork.from_ir(model=self.model_xml, weights=self.model_bin)

        if "CPU" in self.plugin.device:
            supported_layers = self.plugin.get_supported_layers(self.net)
            not_supported_layers = [l for l in self.net.layers.keys() if l not in supported_layers]
            if len(not_supported_layers) != 0:
                log.error("REID: Following layers are not supported by the plugin for specified device {}:\n {}".
                          format(self.plugin.device, ', '.join(not_supported_layers)))
                log.error("REID: Please try to specify cpu extensions library path in sample's command line parameters using -l "
                          "or --cpu_extension command line argument")
                raise ValueError("Some layers are not supported by the plugin for the specified device {}".format(device))

        assert len(self.net.inputs.keys()) == 1, "REID: Sample supports only single input topologies"
        assert len(self.net.outputs) == 1, "REID: Sample supports only single output topologies"
        self.input_blob = next(iter(self.net.inputs))
        self.out_blob = next(iter(self.net.outputs))
        log.info("REID: Loading IR to the plugin...")
        self.exec_net = self.plugin.load(network=self.net)

        self.n, self.c, self.h, self.w = self.net.inputs[self.input_blob].shape
        del self.net

    def identify_face(self, image, add_person = False, name = ""):
        """
        Identifies the face in the supplied image.

        Keyword arguments:
        image: Face to be identified, preferably aligned
        """

        image = image.copy()
        image = image[...,::-1] # Change channel order to RGB
        image = cv2.resize(image, (self.w, self.h))
        image = image.transpose((2, 0, 1))  # Change data layout from HWC to CHW
        image = image.reshape((self.n, self.c, self.h, self.w))

        # Execute inference and parse results
        res = self.exec_net.infer(inputs = {self.input_blob: image})
        embedding = res[self.out_blob].flatten()

        if add_person:
            self.lib.add_new_embedding(embedding, name)
            id, confidence = name, 1.00 # Dummy values
        else:
            id, confidence = self.lib.classify_embedding(embedding)

        return id, confidence

    def save_new_persons(self):
        self.lib.save_library()

### Setup of embedding library class containing known persons
class EmbeddingLibrary(object):
    def __init__(self, known_persons_file, n_neighbors = 5, unknown_threshold = 0.4, classifier_type = "knn"):
        self.known_persons_file = known_persons_file
        self.n_neighbors = n_neighbors
        self.unknown_threshold = unknown_threshold
        self.classifier_type = classifier_type
        self.lib = []
        # self._initialize_classifier()

    def _initialize_classifier(self):
        # Read saved face embeddings from file
        names = []
        embeddings = []
        with open(self.known_persons_file, "r") as file:
            for line in file:
                if len(line) <= 1:
                    continue
                person_data = line.split(" ")
                name = person_data[0]
                embedding = [float(x) for x in person_data[1:]]
                names.append(name)
                embeddings.append(embedding)
                self.lib.append([name] + embedding)
        self.num_persons = len(set([name for name in names]))

        # Initialize classifier model
        if self.classifier_type == "knn":
            self.model = KNeighborsClassifier(n_neighbors = self.n_neighbors, metric = "cosine")
        elif self.classifier_type == "svm":
            self.model = SVC(probability = True)

        # Train model with embedding data
        self.model.fit(embeddings, names)

        print("{} images from {} known persons loaded in model.".format(len(names), self.num_persons))

    def classify_embedding(self, embedding):
        embedding = np.array(embedding).reshape(1, -1)
        if self.classifier_type == "knn":
            n_neighbors = min(len(self.lib), self.n_neighbors)
            id = self.model.predict(embedding)[0]
            dist, _ = self.model.kneighbors(X = embedding, n_neighbors = 1, return_distance = True)
            nearest_distance = dist[0][0]
            if nearest_distance < self.unknown_threshold:
                confidence = 1 - nearest_distance
            else:
                id = "unknown"
                confidence = nearest_distance

        elif self.classifier_type == "svm":
            probs = self.model.predict_proba(embedding)
            print(probs)

        return id, confidence

    def add_new_embedding(self, embedding, name):
        self.lib.append([name] + list(embedding))

    def save_library(self):
        with open(self.known_persons_file, "w") as file:
            file.truncate(0)
            for embedding in self.lib:
                file.write("{} ".format(embedding[0]))
                file.write(" ".join((str(x) for x in embedding[1:])))
                file.write("\n")

### Setup of controller ###

class GenerateController(object):

    def __init__(self, model_detection, model_landmarks, model_id, drawer, directory, output_file):

        self.timer = Timer()
        self.timer.start_task("Setup")

        self.model_detection = model_detection
        self.model_landmarks = model_landmarks
        self.model_id = model_id
        self.drawer = drawer

        self.dir = directory
        self.output_file = output_file
        self.model_name = "SafeHome known persons processing"

        # Clear embeddings file
        with open(self.output_file, "w") as file:
            file.truncate(0)

    def add(self):
        """
        Generator that returns the next frame with detections.
        """

        folders = next(os.walk(self.dir))[1]

        # Go into each folder and open all images in that folder
        for folder in folders:

            image_files = next(os.walk(self.dir + "/" + folder))[2]
            image_id = folder

            for file in image_files:
                # Read image
                image_path = "{}/{}/{}".format(self.dir, folder, file)
                self.current_image = cv2.imread(image_path)

                self.resolution = (self.current_image.shape[1], self.current_image.shape[0])

                self.counters["frames"] += 1

                # Do detection
                self.timer.start_task("Detection")
                bboxes_detected = self.model_detection.detect_objects(self.current_image, self.resolution)

                # Extract faces and find facial landmarks
                self.faces = []
                for n, bbox in enumerate(bboxes_detected):
                    self.timer.start_task("Face alignment")
                    left, top, right, bottom = bbox[2], bbox[3], bbox[4], bbox[5]
                    image_face = self.current_image[top:bottom, left:right].copy()
                    landmarks = self.model_landmarks.detect_facial_landmarks(image_face)
                    image_face_aligned = self.align_face(image_face, landmarks)
                    self.timer.start_task("Face identification")
                    id, confidence = self.model_id.identify_face(image_face_aligned, add_person = True, name = image_id)

                    self.faces.append({"bbox": bbox, "image": image_face,
                                       "image_aligned": image_face_aligned,
                                       "landmarks": landmarks, "id": id,
                                       "confidence": confidence})

                    ## Use this to see the aligned images vs. the original ones. Only for demonstration/debug.
                    # cv2.imwrite("faces/face-{}-{}-orig.jpg".format(self.counters["frames"], n), image_face)
                    # cv2.imwrite("faces/face-{}-{}-aligned.jpg".format(self.counters["frames"], n), image_face_aligned)

                self.timer.start_task("Drawing on image")

                # Calculate FPS
                self.time_this = time.time()
                fps = 1 / (self.time_this - self.time_prev + 0.00001)
                self.time_prev = time.time()

                # Draw overlay
                self.current_image = self.drawer.draw_overlay(self.current_image, fps)

                # Draw bboxes on the image
                self.current_image = self.drawer.draw_bboxes_on_image(self.current_image, self.faces)
                self.current_image = self.drawer.draw_facial_landmarks(self.current_image, self.faces)

                cv2.imshow(self.model_name, self.current_image)
                key = cv2.waitKey(1) & 0xFF
                if key == ord("q"):
                    break

                yield self.current_image

    def initialize(self):

        self.counters = {
            "frames": 0,
        }

        # Initialize time variables to measure FPS
        self.time_start = time.time()
        self.time_this = time.time()
        self.time_prev = time.time()

    def finalize(self):
        cv2.destroyAllWindows()
        self.timer.stop()
        timers = self.timer.get_timers()

        print("\n======== Timer summary ========")
        for key in timers:
            print("{}:{} {:0.4f} seconds \t({:0.4f} s per frame)".format(key, " " * (25-len(key)), timers[key], timers[key] / self.counters["frames"]))

    def align_face(self, image, landmarks):
        height, width, channels = image.shape
        # Define source and target arrays
        points = ["eye_left", "eye_right", "nose", "lip_left", "lip_right"]
        source = [(landmarks[point][0] * width, landmarks[point][1] * height) for point in points]
        targets = [(0.31556875000000000, 0.4615741071428571),
                     (0.68262291666666670, 0.4615741071428571),
                     (0.50026249999999990, 0.6405053571428571),
                     (0.34947187500000004, 0.8246919642857142),
                     (0.65343645833333330, 0.8246919642857142)]
        targets = [(target[0] * width, target[1] * height) for target in targets]

        # Convert arrays to numpy and reshape
        shape = (1, 5, 2) # Needs to be a 3D array
        source = np.array(source).reshape(shape).astype(np.float32)
        targets = np.array(targets).reshape(shape).astype(np.float32)

        # Find transformation matrix and scale to resolution
        transformation = cv2.estimateAffine2D(source, targets)[0]

        # Apply alignment transformation
        image_aligned = cv2.warpAffine(image, transformation, (width, height))

        return image_aligned


### Drawer class (for drawing on images) ###

class OverlayDrawer(object):

    def __init__(self):
        self.font = cv2.FONT_HERSHEY_SIMPLEX
        self.font_scale_very_small = 0.2
        self.font_scale_small = 0.5
        self.font_scale_large = 1.0
        self.thickness_small = 1
        self.thickness_medium = 2
        self.thickness_large = 4
        self.padding = 4

        # Some standard colors to use (BGR)
        self.c_bbox_good = (220, 30, 30) # Blue
        self.c_bbox_bad = (30, 30, 255) # Red
        self.c_landmarks = (30, 255, 20) # Green
        self.c_fps = (30, 255, 20) # Green
        self.c_white = (255, 255, 255) # White

    def draw_bboxes_on_image(self, image, faces, classes_alert = None):

        for n, face in enumerate(faces):
            bbox = face["bbox"]
            classification = face["id"]
            confidence = face["confidence"]
            left, top, right, bottom = bbox[2], bbox[3], bbox[4], bbox[5]

            label = "{} {:.2f}".format(classification, confidence)

            if classes_alert is not None and classification in classes_alert:
                color = self.c_bbox_bad
            else:
                color = self.c_bbox_good

            # Draw main box
            image = cv2.rectangle(image, (left, top), (right, bottom), color, 2)

            # Draw label box above the top left corner of the main box
            label_size = cv2.getTextSize(label, self.font, self.font_scale_small, self.thickness_small)
            label_width = int(label_size[0][0])
            label_height = int(label_size[0][1])

            # If there is space above the box, draw the label there; else draw it below
            if top - label_height > 0:
                label_top = top - label_height - self.padding
            else:
                label_top = bottom

            label_bottom = label_top + label_height + self.padding
            label_left = left
            label_right = left + label_width + self.padding
            image = cv2.rectangle(image, (label_left, label_top), (label_right, label_bottom), color, -1)
            image = cv2.putText(image, label,
                                (label_left + int(self.padding * 0.5), label_bottom - int(self.padding * 0.5)),
                                self.font, self.font_scale_small, self.c_white, self.thickness_small)

        return image

    def draw_facial_landmarks(self, image, faces):
        for face in faces:
            bbox = face["bbox"]
            left, top, right, bottom = bbox[2], bbox[3], bbox[4], bbox[5]
            for point in face["landmarks"]:
                x = left + (right - left) * face["landmarks"][point][0]
                y = top + (bottom - top) * face["landmarks"][point][1]
                image = cv2.circle(image, (x, y), 2, self.c_landmarks, -1)
                # cv2.putText(image, point, (x, y+5), self.font, self.font_scale_small,
                #             self.c_landmarks, self.thickness_small)
        return image

    def draw_overlay(self, image, fps):
        resolution = (image.shape[1], image.shape[0])

        # Add FPS
        cv2.putText(image, "FPS: {:.2f}".format(fps), (3, 25), self.font, self.font_scale_large,
                    self.c_fps, self.thickness_medium)

        return image

### Timer class ###

class Timer(object):
    # Helper class to time task. Every tile start(task) is called, the previous task is stopped and recorded

    def __init__(self):
        self._timers = {}
        self._time_now = time.time()
        self._time_prev = time.time()
        self._curr_task = None

    def start_task(self, task):
        self._time_now = time.time()
        time_passed = self._time_now - self._time_prev
        if self._curr_task is not None:
            self._timers[self._curr_task] = self._timers.get(self._curr_task, 0.0) + time_passed
        self._curr_task = task
        self._time_prev = time.time()

    def stop(self):
        self._time_now = time.time()
        time_passed = self._time_now - self._time_prev
        if self._curr_task is not None:
            self._timers[self._curr_task] = self._timers.get(self._curr_task, 0.0) + time_passed
        self._curr_task = None

    def get_timers(self):
        return self._timers

### Argument parser ###

def people_detector_parser():
    parser = ArgumentParser(description =
        "Adds .")

    # Source video argument
    parser.add_argument("--dir", type = str, required = True,
                        help = "Path to image directory.")

    # Output file argument
    parser.add_argument("--output", type = str, required = True,
                        help = "Path to output file.")

    return parser


### Fixed parameters. Normally do not need to be changed unless adding new models ###

# Should be validated when running on a new installation of OpenVINO
openvino_dir = "/opt/intel/computer_vision_sdk"

# Class names
classes = ["bg", "face"]

# Device management
data_type = {"CPU": "FP32", "GPU": "FP16", "MYRIAD": "FP16"}
model_detection = "Intel face detection"
model_landmarks = "Intel facial landmarks"
model_id = "Intel face reidentification"

model_paths = {"Intel face detection": ("deployment_tools/intel_models/face-detection-adas-0001","face-detection-adas-0001.xml"),
               "Intel facial landmarks": ("deployment_tools/intel_models/landmarks-regression-retail-0009", "landmarks-regression-retail-0009.xml"),
               "Intel face reidentification": ("deployment_tools/intel_models/face-reidentification-retail-0071", "face-reidentification-retail-0071.xml"),
               "SSD-MobileNet face detection": ("deployment_tools/custom_models/caffe_face_detection", "caffe_face_detection.xml")
              }


### Free parameters. Can be changed more freely ###
cpu_extension = "/opt/intel/computer_vision_sdk/deployment_tools/inference_engine/lib/ubuntu_16.04/intel64/libcpu_extension_avx2.so"
plugin_dir = None
device = "CPU" # Options are CPU, GPU (may require updated GPU drivers) and MYRIAD (requires Movidius NCS)
labels_path = None
prob_threshold = 0.6 # Confidence threshold for detections - all detection with lower confidence will be discarded
classes_alert = ["unknown"]

if __name__ == "__main__":

    img_dir = "/home/upsquared/downloads/lfw"
    output_file = "/home/upsquared/safehome/input/known_persons.txt"

    # Parse input arguments and overwrite the defaults if present
    args = people_detector_parser().parse_args()
    img_dir = args.dir
    output_file = args.output

    # Initialize detection model
    model_path_detection = "{}/{}/{}/{}".format(openvino_dir, model_paths[model_detection][0],
                                      data_type[device], model_paths[model_detection][1])
    model_detection = OpenVinoObjectDetectionModel(model_path = model_path_detection,
                                                     classes = classes,
                                                     cpu_extension = cpu_extension,
                                                     plugin_dir = plugin_dir,
                                                     device = device,
                                                     labels_path = labels_path,
                                                     prob_threshold = prob_threshold)

    # Initialize facial landmarks model
    model_path_landmarks = "{}/{}/{}/{}".format(openvino_dir, model_paths[model_landmarks][0],
                                      data_type[device], model_paths[model_landmarks][1])
    model_landmarks = OpenVinoFacialLandmarkModel(model_path = model_path_landmarks,
                                                 cpu_extension = cpu_extension,
                                                 plugin_dir = plugin_dir,
                                                 device = device,
                                                 labels_path = labels_path)

    # Initialize face identification model
    model_path_id = "{}/{}/{}/{}".format(openvino_dir, model_paths[model_id][0],
                                      data_type[device], model_paths[model_id][1])
    model_id = OpenVinoFaceIdentificationModel(model_path = model_path_id,
                                                 cpu_extension = cpu_extension,
                                                 plugin_dir = plugin_dir,
                                                 device = device,
                                                 labels_path = labels_path,
                                                 known_persons_file = output_file)

    # Initialize drawer object
    drawer = OverlayDrawer()

    # Initialize detector class
    detector = GenerateController(model_detection = model_detection,
                                model_landmarks = model_landmarks,
                                model_id = model_id,
                                drawer = drawer,
                                directory = img_dir,
                                output_file = output_file)
    detector.initialize()

    ### Run loop ###
    try:
        for frame in detector.add():
            pass
    except KeyboardInterrupt:
        pass

    model_id.save_new_persons()

    detector.finalize()
