### Imports ###

import sys
import os
from argparse import ArgumentParser
import cv2
import numpy as np
from scipy import spatial
import time
import logging as log
from openvino.inference_engine import IENetwork, IEPlugin
import paho.mqtt.client as mqtt
import json
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import seaborn as sns; sns.set()
import matplotlib.pyplot as plt

### Setup of object detection class ###

class OpenVinoObjectDetectionModel(object):

    def __init__(self, **kwargs):
        """
        Builds an OpenVINO model.

        Keyword arguments (in order):
        model_path: Path to an .xml file with a trained model.
        cpu_extension: MKLDNN (CPU)-targeted custom layers. Absolute path to a shared library with the kernels impl.
        plugin_dir: Path to a plugin folder
        device: Specify the target device to infer on; CPU, GPU, FPGA or MYRIAD is acceptable. CPU by default.
        labels_path: Labels mapping file (format .labels)
        prob_threshold: Probability threshold for detections filtering. Float between 0.0 and 1.0.
        """

        self.__dict__.update(kwargs)
        log.basicConfig(format="[ %(levelname)s ] %(message)s", level=log.INFO, stream=sys.stdout)
        self.generate(**kwargs)
        log.info("DETECT: Model initialized and loaded.")

    def generate(self, model_path, classes, cpu_extension = None, plugin_dir = None, device = "CPU",
                labels_path = None, prob_threshold = 0.5):

        self.model_xml = model_path
        self.model_bin = os.path.splitext(self.model_xml)[0] + ".bin"
        self.classes = classes

        # Plugin initialization for specified device and load extensions library if specified
        log.info("DETECT: Initializing plugin for {} device...".format(device))
        self.plugin = IEPlugin(device=device, plugin_dirs=plugin_dir)
        if cpu_extension and 'CPU' in device:
            self.plugin.add_cpu_extension(cpu_extension)

        # Read IR
        log.info("DETECT: Reading IR...")
        self.net = IENetwork.from_ir(model=self.model_xml, weights=self.model_bin)

        if "CPU" in self.plugin.device:
            supported_layers = self.plugin.get_supported_layers(self.net)
            not_supported_layers = [l for l in self.net.layers.keys() if l not in supported_layers]
            if len(not_supported_layers) != 0:
                log.error("DETECT: Following layers are not supported by the plugin for specified device {}:\n {}".
                          format(self.plugin.device, ', '.join(not_supported_layers)))
                log.error("DETECT: Please try to specify cpu extensions library path in sample's command line parameters using -l "
                          "or --cpu_extension command line argument")
                raise ValueError("DETECT: Some layers are not supported by the plugin for the specified device {}".format(device))

        assert len(self.net.inputs.keys()) == 1, "DETECT: Sample supports only single input topologies"
        assert len(self.net.outputs) == 1, "DETECT: Sample supports only single output topologies"
        self.input_blob = next(iter(self.net.inputs))
        self.out_blob = next(iter(self.net.outputs))
        log.info("DETECT: Loading IR to the plugin...")
        self.exec_net = self.plugin.load(network=self.net)

        self.n, self.c, self.h, self.w = self.net.inputs[self.input_blob].shape
        del self.net

    def detect_objects(self, image, resolution):
        """
        Runs inference on the supplied image.

        Keyword arguments:
        image: Image to be inferenced on
        resolution: Tuple of (width, height) of the image
        """

        image = cv2.resize(image, (self.w, self.h))
        image = image.transpose((2, 0, 1))  # Change data layout from HWC to CHW
        image = image.reshape((self.n, self.c, self.h, self.w))

        # Execute inference and parse results
        res = self.exec_net.infer(inputs = {self.input_blob: image})
        res = res[self.out_blob]
        bboxes = []

        for obj in res[0][0]:
            # Draw only objects when probability more than specified threshold
            confidence = obj[2]
            if confidence > self.prob_threshold:
                xmin = max(0, int(obj[3] * resolution[0]))
                ymin = max(0, int(obj[4] * resolution[1]))
                xmax = min(resolution[0], int(obj[5] * resolution[0]))
                ymax = min(resolution[1], int(obj[6] * resolution[1]))
                class_id = int(obj[1])
                bboxes.append((self.classes[class_id], confidence, xmin, ymin, xmax, ymax))

        return bboxes

### Setup of facial landmark detector
class OpenVinoFacialLandmarkModel(object):

    def __init__(self, **kwargs):
        """
        Builds an OpenVINO model.

        Keyword arguments (in order):
        model_path: Path to an .xml file with a trained model.
        cpu_extension: MKLDNN (CPU)-targeted custom layers. Absolute path to a shared library with the kernels impl.
        plugin_dir: Path to a plugin folder
        device: Specify the target device to infer on; CPU, GPU, FPGA or MYRIAD is acceptable. CPU by default.
        labels_path: Labels mapping file (format .labels)
        prob_threshold: Probability threshold for detections filtering. Float between 0.0 and 1.0.
        """

        self.__dict__.update(kwargs)
        log.basicConfig(format="[ %(levelname)s ] %(message)s", level=log.INFO, stream=sys.stdout)
        self.generate(**kwargs)
        log.info("LANDMARK: Model initialized and loaded.")

    def generate(self, model_path, cpu_extension = None, plugin_dir = None, device = "CPU",
                labels_path = None):

        self.model_xml = model_path
        self.model_bin = os.path.splitext(self.model_xml)[0] + ".bin"

        # Plugin initialization for specified device and load extensions library if specified
        log.info("LANDMARK: Initializing plugin for {} device...".format(device))
        self.plugin = IEPlugin(device=device, plugin_dirs=plugin_dir)
        if cpu_extension and 'CPU' in device:
            self.plugin.add_cpu_extension(cpu_extension)

        # Read IR
        log.info("LANDMARK: Reading IR...")
        self.net = IENetwork.from_ir(model=self.model_xml, weights=self.model_bin)

        if "CPU" in self.plugin.device:
            supported_layers = self.plugin.get_supported_layers(self.net)
            not_supported_layers = [l for l in self.net.layers.keys() if l not in supported_layers]
            if len(not_supported_layers) != 0:
                log.error("LANDMARK: Following layers are not supported by the plugin for specified device {}:\n {}".
                          format(self.plugin.device, ', '.join(not_supported_layers)))
                log.error("LANDMARK: Please try to specify cpu extensions library path in sample's command line parameters using -l "
                          "or --cpu_extension command line argument")
                raise ValueError("Some layers are not supported by the plugin for the specified device {}".format(device))

        assert len(self.net.inputs.keys()) == 1, "LANDMARK: Sample supports only single input topologies"
        assert len(self.net.outputs) == 1, "LANDMARK: Sample supports only single output topologies"
        self.input_blob = next(iter(self.net.inputs))
        self.out_blob = next(iter(self.net.outputs))
        log.info("LANDMARK: Loading IR to the plugin...")
        self.exec_net = self.plugin.load(network=self.net)

        self.n, self.c, self.h, self.w = self.net.inputs[self.input_blob].shape
        del self.net

    def detect_facial_landmarks(self, image):
        """
        Runs inference on the supplied image.

        Keyword arguments:
        image: Image to be inferenced on
        """

        image = image.copy()
        image = image[...,::-1] # Change channel order to RGB
        image = cv2.resize(image, (self.w, self.h))
        image = image.transpose((2, 0, 1))  # Change data layout from HWC to CHW
        image = image.reshape((self.n, self.c, self.h, self.w))

        # Execute inference and parse results
        res = self.exec_net.infer(inputs = {self.input_blob: image})
        res = res[self.out_blob]
        landmarks = {"eye_left": (res[0][0], res[0][1]),
                     "eye_right": (res[0][2], res[0][3]),
                     "nose": (res[0][4], res[0][5]),
                     "lip_left": (res[0][6], res[0][7]),
                     "lip_right": (res[0][8], res[0][9])}

        return landmarks

### Setup of re-identification class
class OpenVinoFaceIdentificationModel(object):

    def __init__(self, **kwargs):
        """
        Builds an OpenVINO model.

        Keyword arguments (in order):
        model_path: Path to an .xml file with a trained model.
        cpu_extension: MKLDNN (CPU)-targeted custom layers. Absolute path to a shared library with the kernels impl.
        plugin_dir: Path to a plugin folder
        device: Specify the target device to infer on; CPU, GPU, FPGA or MYRIAD is acceptable. CPU by default.
        labels_path: Labels mapping file (format .labels)
        known_persons_file: File containing vectors representing known persons
        unknown_threshold: The distance threshold above which a face is classified as unknown. Between 0 and 1.
        classifier_type: The type of classifier to be used
        n_neighbors: Number of neighbors for the KNN classifier
        """

        self.__dict__.update(kwargs)
        log.basicConfig(format="[ %(levelname)s ] %(message)s", level=log.INFO, stream=sys.stdout)
        self.generate(**kwargs)
        self.lib = EmbeddingLibrary(self.known_persons_file, self.n_neighbors, self.unknown_threshold, self.classifier_type)
        log.info("Reidentification model initialized and loaded.")

    def generate(self, model_path, cpu_extension = None, plugin_dir = None, device = "CPU",
                labels_path = None, known_persons_file = None, n_neighbors = None, unknown_threshold = None, classifier_type = None):

        self.model_xml = model_path
        self.model_bin = os.path.splitext(self.model_xml)[0] + ".bin"

        # Plugin initialization for specified device and load extensions library if specified
        log.info("REID: Initializing plugin for {} device...".format(device))
        self.plugin = IEPlugin(device=device, plugin_dirs=plugin_dir)
        if cpu_extension and 'CPU' in device:
            self.plugin.add_cpu_extension(cpu_extension)

        # Read IR
        log.info("REID: Reading IR...")
        self.net = IENetwork.from_ir(model=self.model_xml, weights=self.model_bin)

        if "CPU" in self.plugin.device:
            supported_layers = self.plugin.get_supported_layers(self.net)
            not_supported_layers = [l for l in self.net.layers.keys() if l not in supported_layers]
            if len(not_supported_layers) != 0:
                log.error("REID: Following layers are not supported by the plugin for specified device {}:\n {}".
                          format(self.plugin.device, ', '.join(not_supported_layers)))
                log.error("REID: Please try to specify cpu extensions library path in sample's command line parameters using -l "
                          "or --cpu_extension command line argument")
                raise ValueError("Some layers are not supported by the plugin for the specified device {}".format(device))

        assert len(self.net.inputs.keys()) == 1, "REID: Sample supports only single input topologies"
        assert len(self.net.outputs) == 1, "REID: Sample supports only single output topologies"
        self.input_blob = next(iter(self.net.inputs))
        self.out_blob = next(iter(self.net.outputs))
        log.info("REID: Loading IR to the plugin...")
        self.exec_net = self.plugin.load(network=self.net)

        self.n, self.c, self.h, self.w = self.net.inputs[self.input_blob].shape
        del self.net

    def identify_face(self, image):
        """
        Identifies the face in the supplied image.

        Keyword arguments:
        image: Face to be identified, preferably aligned
        """

        image = image.copy()
        image = image[...,::-1] # Change channel order to RGB
        image = cv2.resize(image, (self.w, self.h))
        image = image.transpose((2, 0, 1))  # Change data layout from HWC to CHW
        image = image.reshape((self.n, self.c, self.h, self.w))

        # Execute inference and parse results
        res = self.exec_net.infer(inputs = {self.input_blob: image})
        embedding = res[self.out_blob].flatten()

        id, confidence = self.lib.classify_embedding(embedding)

        return id, confidence

    def save_new_persons(self):
        self.lib.save_library()

### Setup of embedding library class containing known persons
class EmbeddingLibrary(object):
    def __init__(self, known_persons_file, n_neighbors = 5, unknown_threshold = 0.4, classifier_type = "knn"):
        self.known_persons_file = known_persons_file
        self.n_neighbors = n_neighbors
        self.unknown_threshold = unknown_threshold
        self.classifier_type = classifier_type
        self._initialize_classifier()

    def _initialize_classifier(self):
        # Read saved face embeddings from file
        self.names = []
        self.embeddings = []
        with open(self.known_persons_file, "r") as file:
            for line in file:
                if len(line) <= 1:
                    continue
                person_data = line.split(" ")
                name = person_data[0]
                embedding = [float(x) for x in person_data[1:]]
                self.names.append(name)
                self.embeddings.append(embedding)
        self.num_persons = len(set([name for name in self.names]))

        # Initialize classifier model
        if self.classifier_type == "knn":
            self.model = KNeighborsClassifier(n_neighbors = self.n_neighbors, metric = "cosine", weights = "distance")
        elif self.classifier_type == "svm":
            self.model = SVC(kernel = "linear", probability = True, gamma = "scale")

        # Train model with embedding data
        self.model.fit(self.embeddings, self.names)

        print("{} images from {} known persons loaded in model.".format(len(self.names), self.num_persons))

        # Plot class distribution in compressed space
        # self.plot_class_distribution()

    def classify_embedding(self, embedding):
        embedding = np.array(embedding).reshape(1, -1)
        if self.classifier_type == "knn":
            n_neighbors = min(len(self.names), self.n_neighbors)
            id = self.model.predict(embedding)[0]
            dist, _ = self.model.kneighbors(X = embedding, n_neighbors = 1, return_distance = True)
            nearest_distance = dist[0][0]
            if nearest_distance < self.unknown_threshold:
                confidence = 1 - nearest_distance
            else:
                id = "unknown"
                confidence = nearest_distance

        elif self.classifier_type == "svm":
            probs = self.model.predict_proba(embedding)[0]
            max_prob_idx = np.argmax(probs)
            confidence = probs[max_prob_idx]
            id = self.model.classes_[max_prob_idx]

        return id, confidence

    def plot_class_distribution(self):
        reduction_algo = "tsne"
        if reduction_algo == "pca":
            pca = PCA(n_components = 2)
            pca.fit(self.embeddings)
            reduced = pca.transform(self.embeddings)
        elif reduction_algo == "tsne":
            pca = PCA(n_components = 50)
            pca.fit(self.embeddings)
            reduced_pca = pca.transform(self.embeddings)
            tsne = TSNE(n_components = 2)
            reduced = tsne.fit_transform(reduced_pca)

        ax = sns.scatterplot(x = reduced[:,0], y = reduced[:,1], hue = self.names)
        box = ax.get_position()
        ax.set_position([box.x0, box.y0, box.width * 0.75, box.height])
        ax.legend(loc="center right", bbox_to_anchor = (1.6, 0.5), ncol = 1)
        plt.show()

### Setup of video detection class ###

class SafeHomeDetector(object):

    def __init__(self, model_detection, model_landmarks, model_id,
                 drawer, classes_alert = ["unknown"],
                 resize_resolution = None):

        self.timer = Timer()
        self.timer.start_task("Setup")

        self.model_detection = model_detection
        self.model_landmarks = model_landmarks
        self.model_id = model_id
        self.classes_alert = classes_alert
        self.drawer = drawer

        self.resize_resolution = resize_resolution
        self.resolution = resize_resolution

        self.model_name = "SafeHome person detector"

    def detect(self, show_video = False):
        """
        Generator that returns the next frame with detections.
        """

        while (self.ret):

            self.timer.start_task("Video/image processing")

            # Get next frame from video
            self.ret, self.current_image = self.cap.read()

            # If there are no more frames, exit the loop
            if self.ret == False:
                break

            # Resize if needed
            if self.resize_resolution is not None:
                self.current_image = cv2.resize(self.current_image, self.resolution)

            self.counters["frames"] += 1

            # Do detection
            self.timer.start_task("Detection")
            bboxes_detected = self.model_detection.detect_objects(self.current_image, self.resolution)

            # Extract faces and find facial landmarks
            self.faces = []
            for n, bbox in enumerate(bboxes_detected):
                self.timer.start_task("Face alignment")
                left, top, right, bottom = bbox[2], bbox[3], bbox[4], bbox[5]
                image_face = self.current_image[top:bottom, left:right].copy()
                landmarks = self.model_landmarks.detect_facial_landmarks(image_face)
                image_face_aligned = self.align_face(image_face, landmarks)
                self.timer.start_task("Face identification")
                id, confidence = self.model_id.identify_face(image_face_aligned)

                self.faces.append({"bbox": bbox, "image": image_face,
                                   "image_aligned": image_face_aligned,
                                   "landmarks": landmarks, "id": id,
                                   "confidence": confidence})

                ## Use this to see the aligned images vs. the original ones. Only for demonstration/debug.
                # cv2.imwrite("faces/face-{}-{}-orig.jpg".format(self.counters["frames"], n), image_face)
                # cv2.imwrite("faces/face-{}-{}-aligned.jpg".format(self.counters["frames"], n), image_face_aligned)

            self.timer.start_task("Drawing on image")

            # Calculate FPS
            self.time_this = time.time()
            fps = 1 / (self.time_this - self.time_prev + 0.00001)
            self.time_prev = time.time()

            # Draw overlay
            self.current_image = self.drawer.draw_overlay(self.current_image, fps)

            # Draw bboxes on the image
            self.current_image = self.drawer.draw_bboxes_on_image(self.current_image, self.faces,
                                                                  self.classes_alert)
            # self.current_image = self.drawer.draw_facial_landmarks(self.current_image, self.faces)

            # Write frame to output if applicable
            if self.output_path is not None:
                self.video_output.write(self.current_image)

            # Find number of detected unknown people
            n_detected_unknown = sum((1 for face in self.faces
                                        if face["id"] in self.classes_alert))
            n_detected_known = sum((1 for face in self.faces
                                        if face["id"] not in self.classes_alert))

            if show_video:
                cv2.imshow(self.model_name, self.current_image)
                key = cv2.waitKey(1) & 0xFF
                if key == ord("q"):
                    break

            yield self.current_image, n_detected_known, n_detected_unknown

    def initialize(self, vid_source, output_path):
        self.output_path = output_path

        self.counters = {
            "frames": 0,
        }

        self.cap = cv2.VideoCapture(vid_source)

        # If an output path is specified, create a video output with the same attributes
        # as the input video
        framerate = self.cap.get(cv2.CAP_PROP_FPS)

        if self.resolution is None:
            self.resolution = (int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))

        if self.output_path is not None:
            codec = cv2.VideoWriter_fourcc('m','p','4','v') # fourcc stands for four character code
            self.video_output = cv2.VideoWriter(self.output_path, codec, framerate, self.resolution)
        self.timer.stop()

        # Initialize time variables to measure FPS
        self.time_start = time.time()
        self.time_this = time.time()
        self.time_prev = time.time()

        # Check if video exists
        self.ret, self.current_image = self.cap.read()
        if not self.ret:
            raise ValueError("Video does not exist or can not be opened.")

    def finalize(self):
        cv2.destroyAllWindows()
        self.cap.release()
        if self.output_path is not None:
            self.video_output.release()

        self.timer.stop()
        timers = self.timer.get_timers()

        print("\n======== Timer summary ========")
        for key in timers:
            print("{}:{} {:0.4f} seconds \t({:0.4f} s per frame)".format(key, " " * (25-len(key)), timers[key], timers[key] / self.counters["frames"]))

    def align_face(self, image, landmarks):
        height, width, channels = image.shape
        # Define source and target arrays
        points = ["eye_left", "eye_right", "nose", "lip_left", "lip_right"]
        source = [(landmarks[point][0] * width, landmarks[point][1] * height) for point in points]
        targets = [(0.31556875000000000, 0.4615741071428571),
                     (0.68262291666666670, 0.4615741071428571),
                     (0.50026249999999990, 0.6405053571428571),
                     (0.34947187500000004, 0.8246919642857142),
                     (0.65343645833333330, 0.8246919642857142)]
        targets = [(target[0] * width, target[1] * height) for target in targets]

        # Convert arrays to numpy and reshape
        shape = (1, 5, 2) # Needs to be a 3D array
        source = np.array(source).reshape(shape).astype(np.float32)
        targets = np.array(targets).reshape(shape).astype(np.float32)

        # Find transformation matrix and scale to resolution
        transformation = cv2.estimateAffine2D(source, targets)[0]

        # Apply alignment transformation
        image_aligned = cv2.warpAffine(image, transformation, (width, height))

        return image_aligned


### Setup of MQTT agent class ###

class PeopleDetectorAgent(object):

    def __init__(self, topic):
        #### Setup of MQTT client ####
        # Definition of callbacks that are automatically called
        # on certain events (connection, message sent, message received, etc.)
        def on_connect(client, userdata, flags, rc):
            print("Agent connected to message broker with topic {} and result code {}".format(topic, str(rc)))

        def on_message(client, userdata, msg):
            print(msg.topic + " " + str(msg.payload))

        def on_disconnect(client, userdata, rc):
            print("Agent disconnected from message broker with result code " + str(rc))
            client.loop_stop()

        def on_publish(client, userdata, mid):
            # This can be nice for debugging
            # print("Message successfully sent to broker")
            pass

        # Initialization of client and linking to our callbacks
        self.agent = mqtt.Client(protocol = mqtt.MQTTv31)
        self.agent.on_connect = on_connect
        self.agent.on_message = on_message
        self.agent.on_disconnect = on_disconnect
        self.agent.on_publish = on_publish

        self.topic = topic
        self.last_message_time = 0

        #### JSON setup ####
        # Use dictionaries for JSON messages, since they easily convert to JSON
        # All values except those under "values" remain the same throughout the run

        self.msg_detected =   {"deviceId": "CameraDemo01",
                               "requestId": "CameraDemo01_getAlarm",
                               "serviceName": "alarmService",
                               "actionName": "getAlarm",
                               "type": "EVENT",
                               "level": "INFO",
                               "values":
                                   {"nbKnown": "N/A",
                                    "nbUnknown": "N/A"
                                   }
                              }

    def start_agent(self, hostname, port, username = "", password = ""):
        # Connect to the host
        print("Connecting to {}:{} with user {} and pass {}".format(hostname, port, username, password))
        self.agent.username_pw_set(username, password)
        self.agent.connect(hostname, port)

        # Start loop to ensure that the connection is maintained
        time.sleep(2)
        self.agent.loop_start()


    def send_message(self, n_detected_known, n_detected_unknown):
        n_detected_known = str(int(n_detected_known))
        n_detected_unknown = str(int(n_detected_unknown))
        self.msg_detected["values"]["nbKnown"] = n_detected_known
        self.msg_detected["values"]["nbUnknown"] = n_detected_unknown
        self.agent.publish(self.topic, json.dumps(self.msg_detected))
        print("{} known and {} unknown person(s) detected. Alert message sent to MQTT broker.".format(n_detected_known, n_detected_unknown))

    def stop_agent(self):
        print("Shutting down MQTT client and disconnecting.")
        self.agent.disconnect()

### Drawer class (for drawing on images) ###

class OverlayDrawer(object):

    def __init__(self):
        self.font = cv2.FONT_HERSHEY_SIMPLEX
        self.font_scale_very_small = 0.2
        self.font_scale_small = 0.5
        self.font_scale_large = 1.0
        self.thickness_small = 1
        self.thickness_medium = 2
        self.thickness_large = 4
        self.padding = 4

        # Some standard colors to use (BGR)
        self.c_bbox_good = (220, 30, 30) # Blue
        self.c_bbox_bad = (30, 30, 255) # Red
        self.c_landmarks = (30, 255, 20) # Green
        self.c_fps = (30, 255, 20) # Green
        self.c_white = (255, 255, 255) # White

    def draw_bboxes_on_image(self, image, faces, classes_alert = None):

        for n, face in enumerate(faces):
            bbox = face["bbox"]
            classification = face["id"]
            confidence = face["confidence"]
            left, top, right, bottom = bbox[2], bbox[3], bbox[4], bbox[5]

            label = "{} {:.2f}".format(classification, confidence)

            if classification in classes_alert:
                color = self.c_bbox_bad
            else:
                color = self.c_bbox_good

            # Draw main box
            image = cv2.rectangle(image, (left, top), (right, bottom), color, 2)

            # Draw label box above the top left corner of the main box
            label_size = cv2.getTextSize(label, self.font, self.font_scale_small, self.thickness_small)
            label_width = int(label_size[0][0])
            label_height = int(label_size[0][1])

            # If there is space above the box, draw the label there; else draw it below
            if top - label_height > 0:
                label_top = top - label_height - self.padding
            else:
                label_top = bottom

            label_bottom = label_top + label_height + self.padding
            label_left = left
            label_right = left + label_width + self.padding
            image = cv2.rectangle(image, (label_left, label_top), (label_right, label_bottom), color, -1)
            image = cv2.putText(image, label,
                                (label_left + int(self.padding * 0.5), label_bottom - int(self.padding * 0.5)),
                                self.font, self.font_scale_small, self.c_white, self.thickness_small)

        return image

    def draw_facial_landmarks(self, image, faces):
        for face in faces:
            bbox = face["bbox"]
            left, top, right, bottom = bbox[2], bbox[3], bbox[4], bbox[5]
            for point in face["landmarks"]:
                x = left + (right - left) * face["landmarks"][point][0]
                y = top + (bottom - top) * face["landmarks"][point][1]
                image = cv2.circle(image, (x, y), 2, self.c_landmarks, -1)
                # cv2.putText(image, point, (x, y+5), self.font, self.font_scale_small,
                #             self.c_landmarks, self.thickness_small)
        return image

    def draw_overlay(self, image, fps):
        resolution = (image.shape[1], image.shape[0])

        # Add FPS
        cv2.putText(image, "FPS: {:.2f}".format(fps), (3, 25), self.font, self.font_scale_large,
                    self.c_fps, self.thickness_medium)

        return image

### Timer class ###

class Timer(object):
    # Helper class to time task. Every tile start(task) is called, the previous task is stopped and recorded

    def __init__(self):
        self._timers = {}
        self._time_now = time.time()
        self._time_prev = time.time()
        self._curr_task = None

    def start_task(self, task):
        self._time_now = time.time()
        time_passed = self._time_now - self._time_prev
        if self._curr_task is not None:
            self._timers[self._curr_task] = self._timers.get(self._curr_task, 0.0) + time_passed
        self._curr_task = task
        self._time_prev = time.time()

    def stop(self):
        self._time_now = time.time()
        time_passed = self._time_now - self._time_prev
        if self._curr_task is not None:
            self._timers[self._curr_task] = self._timers.get(self._curr_task, 0.0) + time_passed
        self._curr_task = None

    def get_timers(self):
        return self._timers

### Argument parser ###

def people_detector_parser():
    parser = ArgumentParser(description =
        "Detects people on an incoming video stream.")

    # Source video argument
    parser.add_argument("--video_source", type = str, required = True,
                        help = "Path to video source.")

    # Output video argument
    parser.add_argument("--video_output", type = str,
                        help = "Path to put video output. If not provided \
                                the output video will not be saved.")

    # Hostname argument
    parser.add_argument("--hostname", type = str,
                        help = "Hostname of MQTT broker.")

    # Hostname argument
    parser.add_argument("--port", type = int,
                        help = "Port of MQTT broker.")

    # Username argument
    parser.add_argument("--username", type = str,
                        help = "Username for MQTT user.")

    # Password argument
    parser.add_argument("--password", type = str,
                        help = "Password for MQTT user.")

    # Topic argument
    parser.add_argument("--topic", type = str,
                        help = "Topic for the MQTT messages.")

    # Interval argument
    parser.add_argument("--interval", type = float,
                        help = "Minimum interval in seconds between message transmissions.")

    # Device argument
    parser.add_argument("--device", type = str,
                        help = "Device to run inference on. CPU by default.")

    # Show video argument
    parser.add_argument("--show_video", type = str,
                        help = "Whether to show video output in desktop window (true/false).")

    return parser


### Fixed parameters. Normally do not need to be changed unless adding new models ###

# Should be validated when running on a new installation of OpenVINO
openvino_dir = "/opt/intel/computer_vision_sdk"

# Class names
classes = ["bg", "face"]

# Device management
data_type = {"CPU": "FP32", "GPU": "FP16", "MYRIAD": "FP16"}
model_detection = "Intel face detection"
model_landmarks = "Intel facial landmarks"
model_id = "Intel face reidentification"

model_paths = {"Intel face detection": ("deployment_tools/intel_models/face-detection-adas-0001","face-detection-adas-0001.xml"),
               "Intel facial landmarks": ("deployment_tools/intel_models/landmarks-regression-retail-0009", "landmarks-regression-retail-0009.xml"),
               "Intel face reidentification": ("deployment_tools/intel_models/face-reidentification-retail-0071", "face-reidentification-retail-0071.xml"),
               "SSD-MobileNet face detection": ("deployment_tools/custom_models/caffe_face_detection", "caffe_face_detection.xml")
              }

### Free parameters. Can be changed more freely ###
cpu_extension = "/opt/intel/computer_vision_sdk/deployment_tools/inference_engine/lib/ubuntu_16.04/intel64/libcpu_extension_avx2.so"
plugin_dir = None
device_detect = "CPU" # Options are CPU, GPU (may require updated GPU drivers) and MYRIAD (requires Movidius NCS)
device = "CPU"
labels_path = None
prob_threshold = 0.6 # Confidence threshold for detections - all detection with lower confidence will be discarded
classes_alert = ["unknown"]

video_resolution = (640, 480) # Video will be resized to this size. Set to None for no resizing

unknown_threshold = 0.4
classifier_type = "knn"
n_neighbors = 3

if __name__ == "__main__":

    hostname = "localhost"
    port = 8080
    username = ""
    password = ""
    topic = "home"
    interval = 5
    known_persons_file = "/home/upsquared/safehome/input/known_persons.txt"
    show_video = False

    # Parse input arguments and overwrite the defaults if present
    args = people_detector_parser().parse_args()
    vid_source = args.video_source
    output_path = args.video_output

    if args.hostname:
        hostname = args.hostname
    if args.port:
        port = args.port
    if args.username:
        username = args.username
    if args.password:
        password = args.password
    if args.topic:
        topic = args.topic
    if args.interval:
        interval = args.interval
    if args.device:
        device_detect = args.device
    if args.show_video:
        show_video = args.show_video.lower() in ["true", "yes", "on"]

    # Initialize detection model
    model_path_detection = "{}/{}/{}/{}".format(openvino_dir, model_paths[model_detection][0],
                                      data_type[device_detect], model_paths[model_detection][1])
    model_detection = OpenVinoObjectDetectionModel(model_path = model_path_detection,
                                                     classes = classes,
                                                     cpu_extension = cpu_extension,
                                                     plugin_dir = plugin_dir,
                                                     device = device_detect,
                                                     labels_path = labels_path,
                                                     prob_threshold = prob_threshold)

    # Initialize facial landmarks model
    model_path_landmarks = "{}/{}/{}/{}".format(openvino_dir, model_paths[model_landmarks][0],
                                      data_type[device], model_paths[model_landmarks][1])
    model_landmarks = OpenVinoFacialLandmarkModel(model_path = model_path_landmarks,
                                                 cpu_extension = cpu_extension,
                                                 plugin_dir = plugin_dir,
                                                 device = device,
                                                 labels_path = labels_path)

    # Initialize face identification model
    model_path_id = "{}/{}/{}/{}".format(openvino_dir, model_paths[model_id][0],
                                      data_type[device], model_paths[model_id][1])
    model_id = OpenVinoFaceIdentificationModel(model_path = model_path_id,
                                                 cpu_extension = cpu_extension,
                                                 plugin_dir = plugin_dir,
                                                 device = device,
                                                 labels_path = labels_path,
                                                 known_persons_file = known_persons_file,
                                                 unknown_threshold = unknown_threshold,
                                                 classifier_type = classifier_type,
                                                 n_neighbors = n_neighbors)

    # Initialize MQTT agent
    agent = PeopleDetectorAgent(topic)
    agent.start_agent(hostname, port, username, password)

    # Initialize drawer object
    drawer = OverlayDrawer()

    # Initialize detector class
    detector = SafeHomeDetector(model_detection = model_detection,
                                model_landmarks = model_landmarks,
                                model_id = model_id,
                                drawer = drawer,
                                classes_alert = classes_alert,
                                resize_resolution = video_resolution)
    detector.initialize(vid_source, None)

    ### Run loop ###
    try:
        for frame, n_detected_known, n_detected_unknown in detector.detect(show_video):
            cv2.imwrite("output/img_out.jpg", frame)
            if n_detected_unknown + n_detected_known > 0:
                if time.time() - agent.last_message_time > interval:
                    agent.send_message(n_detected_known, n_detected_unknown)
                    agent.last_message_time = time.time()
    except KeyboardInterrupt:
        pass

    detector.finalize()
