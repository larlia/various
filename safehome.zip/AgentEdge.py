# Imports

import paho.mqtt.client as mqtt
import time
from random import random
import json
import mraa
from upm import pyupm_th02 as th02
from upm import pyupm_grove as grove
import argparse
import socket
import requests

def agent_edge_parser():
    parser = argparse.ArgumentParser(description =
        "Runs an agent that reads temperature, humidity and light and passes \
        them on via MQTT messages.")

    # Hostname argument
    parser.add_argument("--hostname", type = str,
                        help = "Hostname of MQTT broker.")

    # Username argument
    parser.add_argument("--username", type = str,
                        help = "Username for MQTT user.")

    # Password argument
    parser.add_argument("--password", type = str,
                        help = "Password for MQTT user.")

    # Interval argument
    parser.add_argument("--interval", type = float,
                        help = "Interval in seconds between message transmissions.")

    # Light sensor port argument
    parser.add_argument("--light_sensor_port", type = str,
                        help = "Port where light sensor is connected. Normally \
                                between A0 and A2.")

    # Topic argument
    parser.add_argument("--topic", type = str,
                        help = "Topic for the MQTT messages.")

    return parser

class AgentEdge(object):

    def __init__(self, topic):

        #### Setup of MQTT client ####
        # Definition of callbacks that are automatically called
        # on certain events (connection, message sent, message received, etc.)
        def on_connect(client, userdata, flags, rc):
            print("Connected to message broker with topic {} and result code {}".format(topic, str(rc)))

        def on_message(client, userdata, msg):
            print(msg.topic + " " + str(msg.payload))

        def on_disconnect(client, userdata, rc):
            print("Disconnected from message broker with result code " + str(rc))
            client.loop_stop()

        def on_publish(client, userdata, mid):
            # This can be nice for debugging
            # print("Message successfully sent to broker")
            pass

        # Initialization of client and linking to our callbacks
        self.agent = mqtt.Client(protocol = mqtt.MQTTv31)
        self.agent.on_connect = on_connect
        self.agent.on_message = on_message
        self.agent.on_disconnect = on_disconnect
        self.agent.on_publish = on_publish

        self.topic = topic

        #### JSON setup ####
        # Use dictionaries for JSON messages, since they easily convert to JSON
        # All values except those under "values" remain the same throughout the run

        self.msg_temphum = {"deviceId": "SensorDemo01",
                           "requestId": "SensorDemo01_getTempHum",
                           "serviceName": "sensorService",
                           "actionName": "getTempHum",
                           "type": "EVENT",
                           "level": "INFO",
                           "values":
                               {"temperature": "N/A",
                                "humidity": "N/A"
                               }
                          }

        self.msg_light = {"deviceId": "SensorDemo01",
                         "requestId": "SensorDemo01_getLight",
                         "serviceName": "sensorService",
                         "actionName": "getLight",
                         "type": "EVENT",
                         "level": "INFO",
                         "values":
                             {"light": "N/A"
                             }
                          }

        self.msg_presence = {"deviceId": "SensorDemo01",
                         "requestId": "SensorDemo01_getPresence",
                         "serviceName": "sensorService",
                         "actionName": "getPresence",
                         "type": "EVENT",
                         "level": "INFO",
                         "values":
                             {"presence": "N/A"
                             }
                          }


    def start_agent(self, hostname = "localhost", username = "", password = "",
                    interval = 5, port_light = 512):
        # Initialize connections to the sensors
        self.sensor_th = SensorTempHum()
        self.sensor_l = SensorLight(port_light)
        self.sensor_p = SensorPresence()

        # Connect to the host
        self.agent.username_pw_set(username, password)
        self.agent.connect(hostname)

        # Start loop to ensure that the connection is maintained
        self.agent.loop_start()
        time.sleep(2)

        # Main loop - exits by CTRL+C
        counter = 0
        print("Sending messages every {:.1f} seconds. Press CTRL+C to terminate.".format(interval))
        try:
            while True:
                # Get data from sensors and put them in the message dictionaries
                self.msg_temphum["values"]["temperature"] = "{:2.2f}".format(self.sensor_th.get_temperature())
                self.msg_temphum["values"]["humidity"] = "{:2.2f}".format(self.sensor_th.get_humidity())
                self.msg_light["values"]["light"] = "{:2.2f}".format(self.sensor_l.get_light())
                self.msg_presence["values"]["presence"] = self.sensor_p.get_presence()

                # Publish the messages to the broker using the topic "home" (topic is mandatory to include)
                self.agent.publish(self.topic, json.dumps(self.msg_temphum))
                self.agent.publish(self.topic, json.dumps(self.msg_light))
                self.agent.publish(self.topic, json.dumps(self.msg_presence))

                out = "\rSent {} messages successfully / temp: {}  hum: {}  light: {}      "
                print(out.format(counter, self.msg_temphum["values"]["temperature"],
                                 self.msg_temphum["values"]["humidity"],
                                 self.msg_light["values"]["light"]),
                                 end = "", flush = True)
                counter += 1

                # Wait for X seconds until the next message is sent
                time.sleep(interval)
        except KeyboardInterrupt:
            pass

        # Disconnect and shut down (the \b are for deleting
        # the "^C" that appears after a keyboard interrupt)
        print("\b\b  \nShutting down client and disconnecting.")
        self.agent.disconnect()


#### Setup of sensor connections ####

# Temperature/humidity
class SensorTempHum(object):
    def __init__(self):
        self.sensor = th02.TH02()

    def get_temperature(self):
        # return 20.2
        return self.sensor.getTemperature()

    def get_humidity(self):
        # return 50.4
        return self.sensor.getHumidity()

# Light
class SensorLight(object):
    def __init__(self, port = 512):
        self.sensor = grove.GroveLight(port)

    def get_light(self):
        return self.sensor.value()

# Presence
class SensorPresence(object):
    def __init__(self):
        # pin_no = 512 + 7
        # self.pin = mraa.Gpio(pin_no) # TODO
        # time.sleep(0.1)
        # self.pin.dir(mraa.DIR_IN)
        pass

    def get_presence(self):
        # print(self.pin.read())
        return 0 # TODO change


#### Main ####
if __name__ == "__main__":
    # Setup of the Grove subplatform.
    # NOTE: Accessing ports on the subplatform must be done with an offset of 512,
    #       e.g. accessing port D4 is done with the index 516 (= 512 + 4)
    mraa.addSubplatform(mraa.GROVEPI, "0")

    hostname = "localhost"
    username = "upsquared"
    password = "xiot"
    topic = "home"
    interval = 5
    port_light = 512

    # Parse input arguments and overwrite the defaults if present
    args = agent_edge_parser().parse_args()
    if args.hostname:
        hostname = args.hostname
    if args.username:
        username = args.username
    if args.password:
        password = args.password
    if args.topic:
        topic = args.topic
    if args.interval:
        interval = args.interval
    if args.light_sensor_port:
        # If the sensor port input is "A0", "A1" etc., only take the number
        # Also offset the port number by 512.
        port_light = args.light_sensor_port
        if port_light[0].isalpha():
            port_light = port_light[1:]
        port_light = int(port_light) + 512


    ### Send IP address to XIoT server
    # Get internal IP
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        internal_ip = s.getsockname()[0]
    except:
        internal_ip = "127.0.0.1"
    finally:
        s.close()

    # For getting external IP, if necessary
    #external_ip = requests.get("https://ident.me").text

    core_services = "http://ec2-35-180-86-175.eu-west-3.compute.amazonaws.com:8080/e-object-core-services"
    r = requests.get(core_services
                     + "/rest/api/e-object/updateDeviceAttributes/SafeHomeDemo01/general/ipAddress/"
                     + internal_ip,
                     auth = (username, password))
    if r.status_code != 200:
        print("ERROR: Cannot update IP address: " + str(r.status_code))
    else:
        print("IP address successfully sent to X-IoT server.")#

    # Initialize agent and start run
    agent = AgentEdge(topic)
    agent.start_agent(hostname, username, password, interval, port_light)
