#!/bin/bash
SAFEHOME_DIR="/home/upsquared/safehome"
VIDEO_SOURCE="/dev/video0"
HOSTNAME_MQTT="ec2-35-180-86-175.eu-west-3.compute.amazonaws.com"
PORT_MQTT=1883
USERNAME_MQTT="sadmin@nexecur.com"
PASSWORD_MQTT="nexecur"
TOPIC="toM2M"
INTERVAL_SENSORS=10
INTERVAL_DETECTION=1
DEVICE="MYRIAD"
SHOW_VIDEO="false"

sleep 1
cd $SAFEHOME_DIR
mate-terminal --profile Hold \
               --tab -t "PeopleDetector" -e "$SAFEHOME_DIR/run_detector.sh \
                                            $VIDEO_SOURCE $HOSTNAME_MQTT $PORT_MQTT \
                                            $USERNAME_MQTT $PASSWORD_MQTT $TOPIC \
                                            $INTERVAL_DETECTION $DEVICE \
                                            $SAFEHOME_DIR $SHOW_VIDEO" \
               --tab -t "Stream server" -e "sudo twistd -no web --path=$SAFEHOME_DIR --port tcp:80" \
               --tab -t "AgentEdge" -e "sudo python3 $SAFEHOME_DIR/AgentEdge.py \
                                    --light_sensor_port A0 \
                                    --interval $INTERVAL_SENSORS \
                                    --topic $TOPIC \
                                    --hostname $HOSTNAME_MQTT \
                                    --username $USERNAME_MQTT \
                                    --password $PASSWORD_MQTT"  #\
                # --tab -e "firefox --new-window http://ec2-35-180-86-175.eu-west-3.compute.amazonaws.com:8080/e-object-device-management/mng/deviceDashboard" \
                # --tab -e "firefox --new-tab localhost:80"
